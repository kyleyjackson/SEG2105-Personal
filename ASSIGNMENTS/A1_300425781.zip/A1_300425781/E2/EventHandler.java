package ASSIGNMENTS.A1_300425781.E2;

public interface EventHandler {
    void handle(Event event);
}