package ASSIGNMENTS.A1_300425781.E1;

public interface Printable {
    void dump();
}
