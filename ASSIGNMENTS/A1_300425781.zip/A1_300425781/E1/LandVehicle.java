package ASSIGNMENTS.A1_300425781.E1;

public abstract class LandVehicle extends Vehicle {

    // constructors
    public LandVehicle() {
        super();
    }

    public LandVehicle(double weight, double speed) {
        super(weight, speed);
    }
}