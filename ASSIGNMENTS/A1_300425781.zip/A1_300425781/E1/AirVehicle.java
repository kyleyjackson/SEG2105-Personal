package ASSIGNMENTS.A1_300425781.E1;

public abstract class AirVehicle extends Vehicle {
    
    // constructors
    public AirVehicle() {
        super();
    }

    public AirVehicle(double weight, double speed) {
        super(weight, speed);
    }
}